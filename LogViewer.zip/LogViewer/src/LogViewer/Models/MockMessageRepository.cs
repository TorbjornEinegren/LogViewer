﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogViewer.Models
{
    public class MockMessageRepository : IMessageRepository
    {
        public IEnumerable<Message> Messages
        {
            get
            {
                return new List<Message>
                {
                    new Message { timeStamp ="13:37", messageText="I am 1337."},
                    new Message { timeStamp ="17:48", messageText="C# Rocks"},
                    new Message { timeStamp ="18:01", messageText="Helle World!"}
                };
            }
        }
    }
}
