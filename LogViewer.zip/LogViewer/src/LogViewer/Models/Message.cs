﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LogViewer.Models
{
    public class Message
    {
        public string timeStamp { get; set; }
        public string messageText { get; set; }
    }
}
